

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.mapreduce.lib.partition.HashPartitioner;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class AvgTempTaskPart extends Configured implements Tool {
	public static class AvgTempTaskPartitionerMapper extends
			Mapper<LongWritable, Text, IntWritable, DoubleWritable> {

		private IntWritable year = new IntWritable();
		private DoubleWritable temp = new DoubleWritable();

		@Override
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {

			year.set(Integer.parseInt(value.toString().substring(15, 19)));
			temp.set(Double.parseDouble(value.toString().substring(87, 92)));

			context.write(year, temp);
		}
	}

	public static class TskPartitioner extends
			HashPartitioner<IntWritable, DoubleWritable> {
		@Override
		public int getPartition(IntWritable year, DoubleWritable value,
				int numReduceTasks) {
			int intYear = year.get();

			if (numReduceTasks == 0) {
				return 0;
			}

			if (intYear < 1930) {
				return 0;
			} else {
				return 1 % numReduceTasks;
			}

		}
	}

	public static class AvgTempTaskPartitionerReducer extends
			Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> {


		@Override
		public void reduce(IntWritable key, Iterable<DoubleWritable> values,
				Context context) throws IOException, InterruptedException {

			Double tempSum = 0.0, averageTemp=0.0;
			int countValues = 0;

			for (DoubleWritable tempVal : values) {
				tempSum += tempVal.get();
				countValues += 1;
			}
			averageTemp = tempSum / countValues;
			context.write(key, new DoubleWritable(averageTemp));

		}

	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		int res = ToolRunner.run(conf, new AvgTempTaskPart(), args);

		System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {

		Job job = new Job(getConf(), "AvgTempTaskPartitioner");
		job.setJarByClass(AvgTempTaskPart.class);

		job.setMapperClass(AvgTempTaskPartitionerMapper.class);

		job.setMapOutputKeyClass(IntWritable.class);
		job.setMapOutputValueClass(DoubleWritable.class);

		job.setPartitionerClass(TskPartitioner.class);
		job.setReducerClass(AvgTempTaskPartitionerReducer.class);
		job.setNumReduceTasks(2);

		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(DoubleWritable.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));

		Configuration config = new Configuration();
		Path outputPath = new Path(args[1]);
		outputPath.getFileSystem(config).delete(outputPath, true);
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		
		return job.waitForCompletion(true) ? 0 : 1;
	}

}
