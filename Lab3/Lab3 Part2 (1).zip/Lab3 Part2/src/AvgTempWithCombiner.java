
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class AvgTempWithCombiner extends Configured implements Tool {
	public static class AvgTmpWithCombinerMapper extends

	Mapper<LongWritable, Text, IntWritable, DoubleWritable> {

		private IntWritable year = new IntWritable();
		private DoubleWritable temp = new DoubleWritable();

		@Override
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {

			year.set(Integer.parseInt(value.toString().substring(15, 19)));
			temp.set(Double.parseDouble(value.toString().substring(87, 92)));

			context.write(year, temp);
		}
	}

	public static class Combiner extends
			Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> {

		public void reduce(IntWritable year, Iterable<DoubleWritable> values,
				Context context) throws IOException, InterruptedException {

			Double imSum = 0.0, averageTemp = 0.0;
			Integer imCount = 0;

			for (DoubleWritable tmp : values) {

				imSum += tmp.get();
				imCount += 1;
			}

			averageTemp = imSum / imCount;
			context.write(year, new DoubleWritable(averageTemp));

		}

	}

	public static class AvgTmpWithCombinerReducer extends
			Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable> {

		@Override
		public void reduce(IntWritable year, Iterable<DoubleWritable> values,
				Context context) throws IOException, InterruptedException {

			Double imSum = 0.0, averageTemp = 0.0;
			Integer imCount = 0;

			for (DoubleWritable tmp : values) {

				imSum += tmp.get();
				imCount += 1;
			}

			averageTemp = imSum / imCount;
			context.write(year, new DoubleWritable(averageTemp));

		}

	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		int res = ToolRunner.run(conf, new AvgTempWithCombiner(), args);

		System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {

		Job job = new Job(getConf(), "AvgTmpWithCombiner");
		job.setJarByClass(AvgTempWithCombiner.class);

		job.setMapperClass(AvgTmpWithCombinerMapper.class);
		job.setCombinerClass(Combiner.class);
		job.setReducerClass(AvgTmpWithCombinerReducer.class);

		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(DoubleWritable.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));

		Configuration config = new Configuration();
		Path outputPath = new Path(args[1]);
		outputPath.getFileSystem(config).delete(outputPath, true);
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		return job.waitForCompletion(true) ? 0 : 1;
	}

}
